<?php
//Start the session
session_start();

if (isset($_SESSION['email']))
{
	//Read the values from the session	                      通过session把值 传递到 member_page.php
    $first_name = $_SESSION['first_name'];//从session 读取值
    $last_name = $_SESSION['last_name'];
    $phone = $_SESSION['phone'];
    $email = $_SESSION['email'];
	
    //Display a welcome message
    echo"<p> <h2> Welcome back $first_name $last_name </h2> </p>";
    echo"<p> Phone: $phone <br/>";
    echo"Email: $email <br></p>";
	echo"<h2><p> <a href=logout.php>Logout </a> </p></h2> ";
}
else
{
	//redirect back to login form if not authorized
    //redirect back to login form if not authorized
    header("Location: login.html");
    exit;
  	
}
?>

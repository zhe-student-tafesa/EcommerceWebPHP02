<?php
//start the new session
session_start(); ///////////////////////////开始session
//Read the email and the password
$email = $_POST['email'];
$password = $_POST['password'];
if (($email == "") || ($password == "")) { /////////////////////////如果为空
	//Redirect user back to the login page
	header("Location: login.html"); /////////////////////////跳转到login.html
	exit;
} else {
	//connect to server and select database
	require_once('conn_cartdb.php');
	$password=md5($password);// +加密  email10@qq.com  741

	//Create a select query to select user details using the email and the password  使用用户的输入（密码加密后）去查询 数据库
	$query = " SELECT first_name, last_name, phone, email, password 
				from customer WHERE (email = '$email') AND (password = '$password')"; //customer no  s   '$email'加单引号


	$result = mysqli_query($link, $query) or die("Invalid Customer ID or Password"); ////如果查询不成功，则die

	//get the number of rows in the result set; should be 1 if a match
	if (mysqli_num_rows($result) == 1) {///////////////////////////////////////成功登录1、保存数据到session
		//if authorized, get the values of firstname lastname, phone and email
		$row = $result->fetch_row(); //********* 查询结果赋值给  $row
		$first_name = $row[0];
		$last_name = $row[1];
		$phone = $row[2];
		$email = $row[3];
		mysqli_close($link);//关闭 数据库连接
		//save the values in session variables把变量保存在 session里面
		$_SESSION['first_name'] = $first_name;
		$_SESSION['last_name'] = $last_name;
		$_SESSION['phone'] = $phone;
		$_SESSION['email'] = $email;


		echo "<h2> Authentication Succeed !!! </h2>";
		echo "<a href=member_page.php> Click Here to goto Member Page </a>";
	} else {
		//Redirect user back to the login page
		echo"<p> <a href=login.html>Click Here to Login</a> </b></p>";
		exit();
	}
}

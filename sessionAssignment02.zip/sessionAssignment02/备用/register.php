<?php
	//Capture the user inputs from the form
    $first_name=$_POST['first_name']; //Read first name from the form
    $last_name=$_POST['last_name']; //Read last name from the form
    //Read tel. no. from the form
    $phone=$_POST['phone'];

    //Read email from the form
    $email=$_POST['email'];
    //Read password from the form
    $password=$_POST['password'];
    //var_dump($password);
    //echo "</br>"."密码";

    //Read re-password from the form
    $repassword=$_POST['repassword'];


	//Validate user inputs
    if (($first_name == "") or ($last_name == "") or ($email == "")or ($password == ""))
    {
		//Error message to the user
        echo"<p>Required Field(s) missing...!!!! Go back and Try again...!!!!.</p>";
    }
    elseif  (!(strstr($email, "@")) or !(strstr($email, ".")))
    {
        //Error message to the user
        echo"<p>Invalid Email...!!!! Go back and Try again...!!!!.</p>";
    }
    elseif ($password != $repassword)
    {
		//Error message to the user
        echo"<p>Password Miss Match...!!!! Go back and Try again...!!!!.</p>";

    }
    else
    {
    //Connect to the server and add a new record 
	require_once('conn_cartDB.php');
        //加密 成 32位，然后保存
        $password=md5($password);

    echo "</br>"."9/2";
    //var_dump($password);
    //echo "</br>"."9/3";
	//Define the insert query
    $query = "INSERT INTO customer VALUES 
        ('$email','$first_name','$last_name', '$phone','$password')";//注意 顺序，  customer没有s
        
	//Run the query
    mysqli_query($link, $query) or die( "Unable to insert the record");
    mysqli_close($link);
    echo "<p> <b>Record Added Successfully......!!!! </p>";
    echo"<p> <a href=login.html>Click Here to Login to the Member Page </a> </b></p>";
    //Sent a confirmation email to the user
    //mail($email, "Website Email", $message);
    mail("Web Registration", "Your registration is successful", $email);
    

    }
?>

<?php
//Start the session
session_start();
include 'cart.php';
$cart = new Cart();//定义 购物车 实例

if (!isset($_SESSION['counter'])){
    $_SESSION['counter']=0;
    }
$counter = $_SESSION['counter'];


?>
<html>

<body>

    <?php
    //check whether the cart is empty or not

    if ($counter == 0) {
        echo "<h1>Shopping Cart</h1>";
        echo "<br><br><p><b> Your Shopping Cart is empty !!! </b></p>";
        echo "<p><b> <a href=products.php>Go back to products </a> </b></p>";
    } else {
        $cart = unserialize($_SESSION['cart']);

        //Get the depth of the cart
        $depth = $cart->get_depth();

        echo "<h1>Shopping Cart</h1>";
        echo "<table border=1>";
        //         表头     product Name             Quantity                  Price   
        echo "<tr><td><b>product Name</b></td><td><b>Quantity</b></td><td><b> Price</b></td></tr>";
        //Use a for loop to Iterate through the cart
        for ($i = 0; $i < $depth; $i++) {
            $product = $cart->get_product($i);

            $product_id =   $product->get_product_id();
            $product_name = $product->get_product_name();
            $qty =          $product->get_qty();
            $unit_price =   $product->get_unit_price();

            echo "<tr><form  action=remove_from_cart.php method=POST>";                 //增加form表单，每次循环打印一条购物车记录，
                echo "<td>$product_name</td><td>$qty </td><td>$unit_price</td>";//打印 3 个 数据
                echo "<td> <input name= product_no type=checkbox id= product_no value=$i></td>";// name= product_no 传递给 post，值为 $i //checkbox选择是否需要删除
                echo "<td><input  name=remove type=submit id=remove value=Remove></td>";//33333333333要想删除 购物车内容，跳转到  remove_from_cart.php
            echo "</form></tr>";
        }

        echo "</table>";
        echo "<p><b> <a href=checkout.php>Checkout </a> </b></p>";
        echo "<p><b> <a href=products.php>Go back to products </a> </b></p>";
    }
    ?>
</body>

</html>
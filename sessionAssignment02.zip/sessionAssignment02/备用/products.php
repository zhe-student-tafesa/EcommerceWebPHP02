<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta name="author" content="Wink Hosting (www.winkhosting.com)" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="images/style.css" type="text/css" />
	<title>Cash</title>
</head>

<body>
	<div id="page" align="center">
		<div id="toppage" align="center">
			<div id="date">
				<div class="smalltext" style="padding:13px;"><strong>
						<?php
						//echo "&nbsp;".date("Y");
						$today = getdate();
						//         September         几号          2021
						echo " $today[month] $today[mday] $today[year]";
						?>
					</strong></div>
			</div>
			<div id="topbar">
				<div align="right" style="padding:12px;" class="smallwhitetext"><a href="#">Home</a> | <a href="view_cart.php">Cart</a> | <a href="#">Contact Us</a></div>
			</div>
		</div>
		<div id="header" align="center">
			<div class="titletext" id="logo">
				<div class="logotext" style="margin:30px">Ca<span class="orangelogotext">$</span>h</div>
			</div>
			<div id="pagetitle">
				<div id="title" class="titletext" align="right">Welcome to Cash!</div>
			</div>
		</div>
		<div id="content" align="center">
			<div id="menu" align="right">
				<div align="right" style="width:189px; height:8px;"><img src="images/mnu_topshadow.gif" width="189" height="8" alt="mnutopshadow" /></div>
				<div id="linksmenu" align="center">
					<a href="#" title="Home">Home</a>
					<a href="#" title="About Us">About Us</a>
					<a href="products.php" title="Products">Products</a>
					<a href="register.html" title="Register">Register</a>
					<a href="login.html" title="Login">Login</a>
				</div>
				<div align="right" style="width:189px; height:8px;"><img src="images/mnu_bottomshadow.gif" width="189" height="8" alt="mnubottomshadow" /></div>
			</div>
			<div id="contenttext">
				
					<h1> Product Page </h1>
					<table border="1">
						<?php
						//Connet to the database
						require_once("conn_cartdb.php");
						//$query = "SELECT product_id, product_name, unit_price FROM products";  坑人的程序，字段名字与我的不同
						$query = "SELECT item_id, item_name, price FROM products";
						$result = mysqli_query($link, $query);
						//Display products
						//             表头Product Name               Unit Price                Quantity
						echo "<tr><td><b>Product Name</b></td><td><b>Unit Price</b></td><td><b>Quantity</b></td><td></tr>";
						while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							$item_id = $row['item_id'];
							$item_name = $row['item_name']; //$row['item_name'];   item_name：使用数据库 字段的 名字
							$price = $row['price'];
							echo "<tr><form action=add_to_cart.php method=POST>"; //      跳转到 添加到购物车111111111111111
							echo "<input name= item_id type=hidden id=$item_id value=$item_id>"; //不需要 显示的则 加type=hidden进行隐藏
							echo "<td> $item_name</td>"; //name
							echo "<td> $price</td>";   //price
							echo "<td><input name=qty type=text   id=qty value=1 size=2 ></td>"; //input输入   数量
							echo "<td><input name=add type=submit id=add value=Add>      </td>"; //input输入   add按钮
							echo "</form></tr>";
						}
						mysqli_close($link);
						?>
					</table>
				
				
			</div>
		</div>
		<div id="footer" class="smallgraytext" align="center">
			<a href="#">Home</a> | <a href="#">About Us</a> | <a href="#">Products</a> | <a href="#">Our Services</a> | <a href="#">Contact Us</a><br />
			Your Company Name &copy; 2007<br />
			<a href="http://www.winkhosting.com" title="Hosting Colombia">Hosting Colombia</a><br />
		</div>
	</div>
</body>

</html>
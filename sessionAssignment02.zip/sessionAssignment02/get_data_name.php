<html> 
    <!-- 通过产品 名字 模糊 搜索 产品 -->
<head> 
    <!-- <style>
        th {
            border: 1px, solid,black;
        }
        td {
            border: 1px, solid,black;
        }
    </style> -->
    <title>Get Product Data</title> 


    
    <!-- <table border="1"> -->
<?php  
//$fname=1;//$_GET["fname"];
$item_name=$_GET["fname"];
$info="";

//连接
require_once("conn_cartdb.php");
//$query = "SELECT product_id, product_name, unit_price FROM products";  坑人的程序，字段名字与我的不同
//参考 这 个 查询  $query = "SELECT item_id, item_name, price FROM products";
$query = "select * from products where item_name like '%$item_name%'"; //模糊查询 item_name 里面是否 含有   $item_name
$result = mysqli_query($link, $query);

echo "<tr/>";
echo "<tr><td><b>Product Name</b></td><td><b>Unit Price</b></td><td><b>Quantity</b></td><td></tr>";
if(mysqli_num_rows($result)>0){
    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $item_id = $row['item_id'];
        $item_name = $row['item_name'];//$row['item_name'];   item_name：使用数据库 字段的 名字
        $price = $row['price'];
        echo "<tr><form action=add_to_cart.php method=POST>";//      跳转到 添加到购物车111111111111111
            echo "<input name= item_id type=hidden id=$item_id value=$item_id>";//不需要 显示的则 加type=hidden进行隐藏
            echo "<td> $item_name</td>";//name
            echo "<td> $price</td>";   //price
            echo "<td><input name=qty type=text   id=qty value=1 size=2 ></td>";//input输入   数量
            echo "<td><input name=add type=submit id=add value=Add>      </td>";//input输入   add按钮
        echo "</form></tr>";
    }

}else{
    echo "Product with name: $item_name doesn't exist";
}

        mysqli_close($link);



//mysqli_close($link);

   

?> 
    
    <!-- </table>     -->

</head> 
<body> 
    <div id="phpOutput"> <?php echo $info ?> </div> 
</body> 
</html>
<?php

function gen_id($length) {//实现订单号是随机生成的，为了安全
  $id = 0;
  $chars = "012345678936792572378883256937";
  for($i = 0; $i < $length; $i++) {
    $x = rand(0, strlen($chars) -1);
    $id.= substr( $chars,$x,1) ;
  }
  return $id.time();
}
//echo  ( gen_id(5));0763271634260623    76327是随机产生的，1634260623是时间
?>

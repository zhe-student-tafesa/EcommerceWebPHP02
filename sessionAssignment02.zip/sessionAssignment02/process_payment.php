<?php
//Start the session
session_start();
require_once('phpcreditcard.php');
//Read the values from the form
$name=$_POST['name'];
$email=$_POST['email'];
$address=$_POST['address'];
$card_no= $_POST['card_no'];
$code= $_POST['code'];
$exp_date=$_POST['exp_date'];
$card_type=$_POST['card_type'];


//Validate the text fields and the credit card
if (($name=="") or ($email=="") or ($address=="") or
 ($card_no=="") or ($code=="") or ($exp_date=="") or ($card_type==""))
{
    echo"<p>Required Field(s) missing...!!!! Go back and Try again...!!!!.</p>";
}
//Vaidate the email address
elseif  (!(strstr($email,"@")) or !(strstr($email,".")))
{
        echo"<p>Invalid Email...!!!! Go back and Try again...!!!!.</p>";
}
//Call checkCreditCard() function from phpcreditcard.php
elseif (checkCreditCard($card_no, $card_type, $ccerror, $ccerrortext)//校验 银行卡   $cc error text
 != true)
{
echo $ccerrortext;
}
else{
//If there are no errors

 
include 'cart.php';//购物车
require_once('conn_cartDB.php'); // 连接 数据库
require_once('gen_id.php'); //生成 订单号000
$cart = new Cart();
$counter= $_SESSION['counter'];
$total_price=$_SESSION['total_price'];//总价
    	
if ($counter==0){
echo"<br><br><p><b> Your Shopping Cart is empty !!! </b></p>";
}
else {
		//Convert the cart string to a cart object
		$cart = unserialize($_SESSION['cart']);
		$depth = $cart->get_depth();
		//Generate the order id
		$order_id = gen_id(8);//生成 订单号111
		
		//Use a for loop to Iterate through the cart//// 把订单 详情 写入 order_line table
		for ($i=0;$i<$depth;$i++) {
			$product = $cart->get_product($i);
			$product_id = $product->get_product_id();//在 数据库里，我的是item_id
			$qty = $product->get_qty();
			$unit_price = $product->get_unit_price();
			//$total_price = $total_price + ($price*$qty);
			//Add the record to order_line table
			//Create the insert query for the order_line table   把订单 详情 写入 order_line table
			$query = "insert into order_line Values ('$order_id','$product_id','$qty')";
			//Run the query using mysql_query()
			$result=mysqli_query($link, $query) or die("Database Error --Order Line");//$link是在连接数据库 php中定义的
    		
		}



		//Add the record to order table  插入 订单表          order table
		$status = "pending";
		$total_price=$_SESSION['total_price'];
		//Create the insert query for the order table
    	$query ="insert into orders Values ('$order_id','$email','$total_price','$status')";
			//Run the query using mysql_query()
		$result=mysqli_query($link, $query) or die("Database Error --Orders");

		
		
		echo "Thank you for the order your order number is $order_id <br> Your order details has been emailed to your $_POST[email]";
		//Email the invoice
		//mail($email,"Order Confirmation",$msg);
		mysqli_close($link);
		
		//Empty the cart
		unset($_SESSION['counter']);
		unset($_SESSION['cart']);

		//session_destroy();//不能销毁，否则 登录 信息 都丢了
		
		echo"<p><b> <a href=products.php>Go back to Products </a> </b></p>";
	}
}

?>

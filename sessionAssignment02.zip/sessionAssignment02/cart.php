<?php

class Product
{

    var $product_id;
    var $product_name;
    var $qty;
    var $unit_price;

    function get_product_cost()
    {
        return $this->qty * $this->unit_price;//数量*单价
    }

    function __construct($product_id, $product_name, $qty, $unit_price)
    {
        $this->product_id = $product_id;
        $this->product_name = $product_name;
        $this->qty = $qty;
        $this->unit_price = $unit_price;
    }

    function get_product_id()//get
    {
        return $this->product_id;
    }

    function get_product_name()
    {
        return $this->product_name;
    }

    function get_qty()
    {
        return $this->qty;
    }

    function get_unit_price()
    {
        return $this->unit_price;
    }
}

class Cart//一个Cart 里面 有  很多产品 products 
{

    var $products;
    var $depth;//相当于索引

    function __construct()
    {
        $this->products = array();//这些产品放在这个数组里面
        $this->depth = 0;
    }

    function add_product($product)
    {
        // 相当于JS 中的this.products（thi.depth）  
        $this->products[$this->depth] = $product;//cart 里面 增加一个 产品
        $this->depth++;
    }

    function delete_product($product_no)
    {
        unset($this->products[$product_no]);
        $this->products = array_values($this->products);//返回数组中所有的值（不保留键名）：
        $this->depth--;
    }

    function get_depth()
    {
        return $this->depth;
    }

    function get_product($product_no)//  这个$product_no 是 0 1 2 3 不是产品id  
    {
        return $this->products[$product_no];
    }
}

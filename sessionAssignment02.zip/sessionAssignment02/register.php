<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta name="author" content="Wink Hosting (www.winkhosting.com)" />
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="images/style.css" type="text/css" />
	<title>Cash</title>
</head>
<body>
	<div id="page" align="center">
		<div id="toppage" align="center">
			<div id="date">
				<div class="smalltext" style="padding:13px;"><strong>April 21, 2007</strong></div>
			</div>
			<div id="topbar">
				<div align="right" style="padding:12px;" class="smallwhitetext"><a href="#">Home</a> | <a href="view_cart.php">Cart</a> | <a href="#">Contact Us</a></div>
			</div>
		</div>
		<div id="header" align="center">
			<div class="titletext" id="logo">
				<div class="logotext" style="margin:30px">Ca<span class="orangelogotext">$</span>h</div> 
			</div>
			<div id="pagetitle">
				<div id="title" class="titletext" align="right">Welcome to Cash!</div>
			</div>
		</div>
		<div id="content" align="center">
		<?php
	//Capture the user inputs from the form
    $first_name=$_POST['first_name']; //Read first name from the form
    $last_name=$_POST['last_name']; //Read last name from the form
    //Read tel. no. from the form
    $phone=$_POST['phone'];

    //Read email from the form
    $email=$_POST['email'];
    //Read password from the form
    $password=$_POST['password'];
    //var_dump($password);
    //echo "</br>"."密码";

    //Read re-password from the form
    $repassword=$_POST['repassword'];


	//Validate user inputs
    if (($first_name == "") or ($last_name == "") or ($email == "")or ($password == ""))
    {
		//Error message to the user
        echo"<p>Required Field(s) missing...!!!! Go back and Try again...!!!!.</p>";
    }
    elseif  (!(strstr($email, "@")) or !(strstr($email, ".")))
    {
        //Error message to the user
        echo"<p>Invalid Email...!!!! Go back and Try again...!!!!.</p>";
    }
	elseif (!is_numeric($phone))
    {
		//Error message to the user
        echo"<p>Telephone number must be numeric...!!!! Go back and Try again...!!!!.</p>";

    }
    elseif ($password != $repassword)
    {
		//Error message to the user
        echo"<p>Password Miss Match...!!!! Go back and Try again...!!!!.</p>";

    }
    else
    {
    //Connect to the server and add a new record 
	require_once('conn_cartDB.php');
        //加密 成 32位，然后保存
        $password=md5($password);

    echo "</br>"."9/2";
    //var_dump($password);
    //echo "</br>"."9/3";
	//Define the insert query
    $query = "INSERT INTO customer VALUES 
        ('$email','$first_name','$last_name', '$phone','$password')";//注意 顺序，  customer没有s
        
	//Run the query
    mysqli_query($link, $query) or die( "Unable to insert the record");
    mysqli_close($link);
    echo "<p> <b>Record Added Successfully......!!!! </p>";
    echo"<p> <a href=login.html>Click Here to Login to the Member Page </a> </b></p>";
    //Sent a confirmation email to the user
    //mail($email, "Website Email", $message);
    mail("Web Registration", "Your registration is successful", $email);
    

    }
?>
		
		<div id="contenttext">
			<div class="bodytext" style="padding:12px;" align="justify">
				<strong>Hi! This is my second design for OSWD, with CSS and XHTML 1.0 Transitional Validation. You can do whatever you want with this template, just keep the Hosting Colombia link	at the bottom. Enjoy!			  </strong><br />
				<br />
				Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur id est   tincidunt nisl pellentesque tincidunt. Donec in mauris. Mauris neque magna,   consectetuer id, malesuada vitae, tincidunt sit amet, mi. Aliquam lacinia.   Suspendisse potenti. Proin justo lorem, rutrum ac, facilisis in, malesuada sed,   ligula. Mauris lobortis lacus at nibh. Aenean vitae odio vel odio placerat   hendrerit. Suspendisse lacus lacus, tempor id, pharetra eget, ornare sit amet,   pede. Sed aliquet, justo ac elementum pretium, arcu leo placerat est, a luctus   purus diam eget arcu. Nam augue diam, mollis a, scelerisque eget, aliquet   condimentum, pede. Vestibulum tristique lectus sed augue.
			</div>
			<div class="panel" align="justify">
				<span class="orangetitle">Some Title Here</span>
				<span class="bodytext"><br />
				Nullam et ipsum condimentum pede luctus consequat. Nulla venenatis mi a sapien. Nunc facilisis pede quis nisl. Duis eget sapien. Suspendisse potenti. Vestibulum eget ligula in ante pharetra imperdiet. Maecenas vehicula luctus mi. Suspendisse molestie libero vitae magna. Integer metus tortor, mollis eleifend, tincidunt in, sagittis eget, lorem. Donec posuere. Curabitur ut eros. Praesent vitae sem facilisis tellus euismod scelerisque. Donec pellentesque. Vestibulum scelerisque, turpis pellentesque sollicitudin nonummy, ipsum erat consequat augue, ut tincidunt urna magna ut leo. Nullam ullamcorper metus vitae est. Ut diam metus, molestie porttitor, pretium vitae, ultricies nec, pede. Maecenas bibendum dictum tellus. Vestibulum feugiat, velit quis eleifend pharetra, leo lacus laoreet diam, quis laoreet arcu mi vel felis.			</span>			</div>
			</div>
		</div>
		<div id="footer" class="smallgraytext" align="center">
			<a href="#">Home</a> | <a href="#">About Us</a> | <a href="#">Products</a> | <a href="#">Our Services</a> | <a href="#">Contact Us</a><br />
			Your Company Name &copy; 2007<br />
			<a href="http://www.winkhosting.com" title="Hosting Colombia">Hosting Colombia</a><br />
		</div>
	</div>
</body>
</html>

//   AJAX必须使用这3 个函数   function getHTTPObject()  function handleHttpResponse()   function requestUserInfo 
function getHTTPObject() {
    var xmlhttp;
    if (window.XMLHttpRequest) {
        // Chrome, Firefox, Safari
        xmlhttp = new XMLHttpRequest();
    } else {
        //Internet Explorer
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        if (!xmlhttp) {
            xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
        }

    }
    return xmlhttp;
}
//Create the HTTP Object 
var http = getHTTPObject();

function handleHttpResponse() {
    if ((http.readyState == 4) && (http.status == 200)) {

        var results = http.responseText;
        document.getElementById('custInfo').innerHTML = results;
    }
}

// The server-side script URL
var url = "get_data_name.php?fname="; //修改 php 和传递变量的名称

function requestUserInfo() {
    var Name = document.getElementById("fname").value;
    http.open("GET", url + Name, true);
    http.onreadystatechange = handleHttpResponse;
    http.send(null);
}
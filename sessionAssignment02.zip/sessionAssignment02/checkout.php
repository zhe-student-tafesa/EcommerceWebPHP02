<?php
//Start the session
session_start();

include 'cart.php';
$cart = new Cart();
$counter = $_SESSION['counter'];
$total_price=0;
////check whether the cart is empty or not
if ($counter==0){
    echo"<br><br><p><b> Your Shopping Cart is empty !!! </b></p>";
}
    
else {
    $cart = unserialize($_SESSION['cart']);
    $depth = $cart->get_depth();
    echo"<h1>Shopping Cart</h1>";
    echo "<table border=1>";
    echo"<tr><td><b>Product Name</b></td><td><b>Quantity</b></td><td><b> Price</b></td></tr>";
    
    //$deleted=0;
	//Use a for loop to Iterate through the cart
    for ($i=0;$i<$depth;$i++) {
        $product = $cart->get_product($i);
		$product_id = $product->get_product_id();
		$product_name = $product->get_product_name();
		$qty = $product->get_qty();
		$unit_price = $product->get_unit_price();
		//Calculate the total price
		$total_price = $total_price+$unit_price*$qty; //循环打印         一种  商品的  单价*数量  循环
		echo"<tr><td>$product_name</td><td>$qty </td><td>$unit_price</td></tr>";//一种  商品的  信息显示
        }
    }
   //Display the total price
   $_SESSION['total_price']=$total_price;//保存到_SESSION中，才能 在其他页面get    //保存到_SESSION中，才能 在其他页面get    
   echo"<tr><td>Total</td><td>&nbsp; </td><td>$".number_format($total_price,2)."</td></tr>";//所有  商品的  信息显示 (格式化显示，加$ ) $".number_format($total_price,2)."

    echo "</table>";
    echo"<p><b> <a href=view_cart.php>Remove prices from the Cart </a> </b></p>";
    echo"<p><b> <a href=payments.php>Proceed with Payments</a> </b></p>";
    echo"<p><b> <a href=paypal_test.php>Proceed with PayPal</a> </b></p>";
    echo"<p><b> <a href=products.php>Go back to products </a> </b></p>";

?>
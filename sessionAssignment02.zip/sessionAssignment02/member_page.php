<?php
                //Start the session
                session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta name="author" content="Wink Hosting (www.winkhosting.com)" />
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" href="images/style.css" type="text/css" />
    <title>Cash</title>
</head>

<body>
    <div id="page" align="center">
        <div id="toppage" align="center">
            <div id="date">
                <div class="smalltext" style="padding:13px;"><strong>April 21, 2007</strong></div>
            </div>
            <div id="topbar">
                <div align="right" style="padding:12px;" class="smallwhitetext"><a href="#">Home</a> | <a href="view_cart.php">Cart</a> | <a href="#">Contact Us</a></div>
            </div>
        </div>
        <div id="header" align="center">
            <div class="titletext" id="logo">
                <div class="logotext" style="margin:30px">Ca<span class="orangelogotext">$</span>h</div>
            </div>
            <div id="pagetitle">
                <div id="title" class="titletext" align="right">Welcome to Cash!</div>
            </div>
        </div>
        <div id="content" align="center">
            <div id="menu" align="right">
                <div align="right" style="width:189px; height:8px;"><img src="images/mnu_topshadow.gif" width="189" height="8" alt="mnutopshadow" /></div>
                <div id="linksmenu" align="center">
                    <a href="#" title="Home">Home</a>
                    <a href="#" title="About Us">About Us</a>
                    <a href="products.php" title="Products">Products</a>
                    <a href="register.html" title="Register">Register</a>
                    <a href="login.html" title="Login">Login</a>
                </div>
                <div align="right" style="width:189px; height:8px;"><img src="images/mnu_bottomshadow.gif" width="189" height="8" alt="mnubottomshadow" /></div>
            </div>
            <div id="contenttext">
               
               
               <?php
                //Start the session
                //session_start();

                if (isset($_SESSION['email'])) {
                    //Read the values from the session	                      通过session把值 传递到 member_page.php
                    $first_name = $_SESSION['first_name']; //从session 读取值
                    $last_name = $_SESSION['last_name'];
                    $phone = $_SESSION['phone'];
                    $email = $_SESSION['email'];

                    //Display a welcome message
                    echo "<p> <h2> Welcome back $first_name $last_name </h2> </p>";
                    echo "<p> Phone: $phone <br/>";
                    echo "Email: $email <br></p>";
                    echo "<h2><p> <a href=logout.php>Logout </a> </p></h2> ";
                } else {
                    //redirect back to login form if not authorized
                    //redirect back to login form if not authorized
                    header("Location: login.html");
                    exit;
                }
                ?>
            </div>
            <div id="footer" class="smallgraytext" align="center">
                <a href="#">Home</a> | <a href="#">About Us</a> | <a href="#">Products</a> | <a href="#">Our Services</a> | <a href="#">Contact Us</a><br />
                Your Company Name &copy; 2007<br />
                <a href="http://www.winkhosting.com" title="Hosting Colombia">Hosting Colombia</a><br />
            </div>
        </div>
</body>

</html>
<?php
session_start();
include 'cart.php';
//get the product_id and the quantity
$product_id = $_POST['item_id'];//注意变量 名字不同
$qty = $_POST['qty'];
$cart = new Cart();
$counter = 0;
//store number of products in the shopping cart
if ((isset($_SESSION['counter'])) && ($_SESSION['counter'] != 0)) {//不是 第一次 添加时，$_SESSION['counter']里面有值
    $counter = $_SESSION['counter'];         //必须保存Nadil                                         //取出 counter？
    // unserialize convert the session object which is a string to a cart object
    //serialize()：这个函数作用就是序列化数据，返回一个可存储的字符串，该函数有利于存储或传递PHP的值，同时不丢失其类型和结构。
    ////必须使用unserialize 把  文本转为对象 ，才能 保存在 cart里面
    $cart = unserialize($_SESSION['cart']);
} else {//第一次点击 增加
    $_SESSION['counter'] = 0;//第一次点击 增加
    $_SESSION['cart'] = "";
}




if (($product_id == "") or ($qty < 1)) {//数量 必须大于等于1
    header("Location: products.php");
    exit;
} else {
    //connect to server and select database
    require_once('conn_cartdb.php');
    $query = "SELECT item_name, price from products WHERE (item_id = '$product_id') ";//注意 字段 名字    '$product_id'需要加单引号
    $result = mysqli_query($link, $query) or die("Database Error");//不成功 就die
    if (mysqli_num_rows($result) == 1) {//如果查询 结果为 1条（成功）
        $row = $result->fetch_assoc();                       //调用 fetch_assoc()方法，取一条记录
        $product_name = $row['item_name'];////注意 字段 名字
        $unit_price = $row['price'];//注意 字段 名字
       
       
        //add product to the cart 创建 实例
        $new_product = new product(
            $product_id,
            $product_name,
            $qty,
            $unit_price
        );


        $cart->add_product($new_product);//Cart实例对象  调用 add_product方法


        //update the counter
        $_SESSION['counter'] = $counter + 1;
        //Convert the cart to a text object and store in a session  将购物车转换为 文本对象并存储在会话中
        //必须使用serialize把 对象转为 文本，才能 保存在 session里面
        $_SESSION['cart'] = serialize($cart);//2222222222222222222把购物车保存到session后，跳转到 view cart.php  22222222222222222222
        //print_r($cart);//调试用，此时需要注释掉 //header("Location: view_cart.php"); exit();
        header("Location: view_cart.php");
        exit();
    } else {
        header("Location: products.php");
        exit();
    }
    mysqli_close($link);
}

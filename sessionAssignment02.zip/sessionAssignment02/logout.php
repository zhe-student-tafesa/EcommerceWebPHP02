<?php
	session_start();

	//Distroy the session
	unset($_SESSION['email']);
	unset($_SESSION['counter']);
	unset($_SESSION['cart']);
	session_destroy();
	
	//Redirect user back to the login page
	header("Location: login.html");
   	exit;

?>

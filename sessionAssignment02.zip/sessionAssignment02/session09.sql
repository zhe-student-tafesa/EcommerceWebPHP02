//在 这个链接运行 以下SQL代码

use cartdb;

CREATE TABLE IF NOT EXISTS  orders(
    order_ID varchar(30) not null primary key, 
    email Varchar(30) not null, 
	total_amount decimal(6,2) not null,
	status Varchar(15) not null

);

CREATE TABLE IF NOT EXISTS  order_line(
    order_ID varchar(30) not null , 

     item_id Varchar(6) not null, 
	qty int(4) not null

);



-- insert into  products (Product_ID,Product_Name,Unit_Price,Qty ) values
-- ('1001','Pen',12.50,10),
-- ('1002','book',13.50,19),
-- ('1003','64 GB USB',18.99,100),
-- ('1004','2TB SSD',128.50,10);